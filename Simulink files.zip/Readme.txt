ACDC.slx is the simulation of front-end rectifier
DCDC.slx is the simulation of EV charger (DC voltage source to battery)
V2G.slx is the simulation of the whole V2G & G2V system